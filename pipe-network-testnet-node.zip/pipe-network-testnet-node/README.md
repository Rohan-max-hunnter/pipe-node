# Pipe Network Testnet Node

This repository contains configuration and scripts for setting up a Pipe Network Testnet node.

## Requirements

- Ubuntu 20.04 or 22.04
- 4+ CPU cores
- 16GB RAM
- 100GB+ SSD storage
- 1Gbps internet

## Setup

1. Clone the repo:
   ```bash
   git clone https://github.com/YOUR_USERNAME/pipe-network-testnet-node.git
   cd pipe-network-testnet-node
   ```

2. Install dependencies:
   ```bash
   sudo apt update && sudo apt install -y libssl-dev ca-certificates
   ```

3. Update system tuning:
   ```bash
   sudo sysctl -p /etc/sysctl.d/99-popcache.conf
   ```

4. Place your binary and config in `/opt/popcache`.

## Running as a service

Install `popcache.service` to run your node in the background.

```bash
sudo cp popcache.service /etc/systemd/system/
sudo systemctl daemon-reexec
sudo systemctl enable --now popcache
```

## License

MIT
